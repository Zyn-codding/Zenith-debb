// ©AiiSigma

module.exports = {
  domain: "http://privatapip.pterodaytl.my.id", // Ganti sma domain panel lu dan pastiin harus *http*
  port: "4034" // Ganti Portnoy di panel network.
};